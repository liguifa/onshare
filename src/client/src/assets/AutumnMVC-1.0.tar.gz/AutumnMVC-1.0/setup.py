from setuptools import find_packages, setup

setup(name='AutumnMVC',
      version='1.0',
      description='一个依赖大于配置的MVC框架',
      author='Guifa Li',
      author_email='github.liguifa@outlook.com',
      url='https://www.github.com/liguifa/autumnMVC')
